import Header from '../components/Header'
import Footer from '../components/Footer'
import ServiceCard from '../components/ServiceCard'
import fs from 'fs'
import path from 'path'

const services = [
  { title: 'Reliance Energy Limited - Bill Distribution', desc: 'Distribution of electricity bills for Reliance Energy Limited.' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-electricity.svg'),'utf8') },
  { title: 'Adani Electricity Mumbai - Bill Distribution & Meter Reading', desc: 'Bill distribution and meter reading services for Adani Electricity Mumbai.' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-electricity.svg'),'utf8') },
  { title: 'Adani Electricity - Smart Meter Replacement', desc: 'Smart meter replacement and installation services.' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-electricity.svg'),'utf8') },
  { title: 'Mahanagar Gas Ltd - Payment Recovery & Disconnection', desc: 'Payment recovery, collection and disconnection services for Mahanagar Gas.' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-gas.svg'),'utf8') },
  { title: 'Mahavitran - Bill Distribution, Meter Reading & Printing', desc: 'Services for Maharashtra State Electricity distribution (Mahavitran).' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-electricity.svg'),'utf8') },
  { title: 'Citizen Services - Aadhaar / Passport / PAN / Voter ID', desc: 'Assistance with Aadhaar, Passport, PAN card, and voter ID services.' , icon: fs.readFileSync(path.join(process.cwd(),'public','icon-docs.svg'),'utf8') }
]

export default function Services(){
  return (
    <div className="min-h-screen flex flex-col">
      <Header/>
      <main className="container mx-auto px-6 py-12 flex-1">
        <h1 className="text-3xl font-bold text-blue-900">Services</h1>
        <p className="mt-2 text-gray-700">Detailed list of services we provide.</p>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map((s,idx)=> <ServiceCard key={idx} title={s.title} desc={s.desc} icon={s.icon} />)}
        </div>
      </main>
      <Footer/>
    </div>
  )
}
