import Header from '../components/Header'
import Footer from '../components/Footer'

export default function About(){
  return (
    <div className="min-h-screen flex flex-col">
      <Header/>
      <main className="container mx-auto px-6 py-12 flex-1">
        <h1 className="text-3xl font-bold text-blue-900">About S&P ENTERPRISES</h1>
        <p className="mt-4 text-gray-700">S&P ENTERPRISES, led by owner <strong>Satish Dhakne</strong>, provides authorized utility services and citizen assistance across Mumbai and Maharashtra. We specialize in bill distribution, meter reading, smart meter replacement, payment recovery, and document services.</p>
        <div className="mt-6">
          <h2 className="text-2xl font-semibold">Our Commitment</h2>
          <p className="mt-2 text-gray-600">We prioritize timely service, accuracy, and professionalism in all our operations.</p>
        </div>
      </main>
      <Footer/>
    </div>
  )
}
