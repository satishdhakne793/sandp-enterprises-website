import Header from '../components/Header'
import Footer from '../components/Footer'
import ContactForm from '../components/ContactForm'

export default function Contact(){
  return (
    <div className="min-h-screen flex flex-col">
      <Header/>
      <main className="container mx-auto px-6 py-12 flex-1">
        <h1 className="text-3xl font-bold text-blue-900">Contact Us</h1>
        <p className="mt-2 text-gray-700">Reach out for service enquiries or document assistance.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="font-semibold">Contact Details</h2>
            <p className="mt-2">Phone: 9892255431, 9702055431</p>
            <p className="mt-1">Email: sandpenterprises793@gmail.com</p>
            <p className="mt-1">Address: Shop No 5, Krishna Colony, Opp SBI Bank, R T Road, Dahisar East, Mumbai 400068</p>
          </div>
          <div>
            <ContactForm/>
          </div>
        </div>
      </main>
      <Footer/>
    </div>
  )
}
