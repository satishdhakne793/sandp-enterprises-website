export default function ServiceCard({title, desc, icon}){
  return (
    <div className="border rounded-lg p-5 shadow-sm hover:shadow-md transition">
      <div className="h-12 w-12 mb-3" dangerouslySetInnerHTML={{__html: icon}} />
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm text-gray-600">{desc}</p>
    </div>
  )
}
