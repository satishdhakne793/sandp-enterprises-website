import { useState } from 'react'

const FORM_ENDPOINT = '' // <-- Replace with your Formspree endpoint, e.g. 'https://formspree.io/f/xxxxxx'

export default function ContactForm(){
  const [state, setState] = useState({name:'', email:'', message:''})
  const [sent, setSent] = useState(false)
  const onChange = (e)=> setState({...state, [e.target.name]: e.target.value})

  const submit = async(e)=>{
    e.preventDefault()
    if(!FORM_ENDPOINT){ 
      alert('Form not connected. Add your Formspree endpoint in components/ContactForm.js')
      return
    }
    try{
      const res = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: state.name, email: state.email, message: state.message })
      })
      if(res.ok) setSent(true)
    }catch(err){
      console.error(err); alert('Failed to send, try later.')
    }
  }

  if(sent) return <div className="p-4 bg-green-50 border rounded">Thank you — your message was sent.</div>

  return (
    <form onSubmit={submit} className="space-y-3 max-w-xl">
      <div>
        <label className="block text-sm font-medium">Name</label>
        <input name="name" value={state.name} onChange={onChange} className="w-full border rounded px-3 py-2" required/>
      </div>
      <div>
        <label className="block text-sm font-medium">Email</label>
        <input name="email" type="email" value={state.email} onChange={onChange} className="w-full border rounded px-3 py-2" required/>
      </div>
      <div>
        <label className="block text-sm font-medium">Message</label>
        <textarea name="message" value={state.message} onChange={onChange} className="w-full border rounded px-3 py-2" rows="5" required/>
      </div>
      <div>
        <button type="submit" className="bg-blue-700 text-white px-4 py-2 rounded">Send Message</button>
      </div>
    </form>
  )
}
