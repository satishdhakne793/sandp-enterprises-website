export default function Footer(){
  return (
    <footer className="bg-blue-900 text-white mt-12">
      <div className="container mx-auto px-6 py-8">
        <div className="text-sm">
          <strong>S&P ENTERPRISES</strong><br/>
          Shop No 5, Krishna Colony, Opp SBI Bank, R T Road, Dahisar East, Mumbai 400068<br/>
          Phone: 9892255431, 9702055431 | Email: sandpenterprises793@gmail.com
        </div>
        <div className="mt-4 text-xs opacity-90">© 2025 S&P ENTERPRISES. All rights reserved.</div>
      </div>
    </footer>
  )
}
