S&P ENTERPRISES — Next.js + Tailwind Website
------------------------------------------------

This project is prepared for quick deployment on Vercel.

What’s included:
- Multi-page Next.js site: Home, About, Services, Contact
- Tailwind CSS setup (PostCSS + tailwindcss)
- Logo (SVG) and simple service icons (SVG)
- Contact form wired for Formspree (not connected). Replace the FORM_ENDPOINT in /components/ContactForm.js with your Formspree endpoint.

How to deploy on Vercel (recommended):
1. Unzip the project locally.
2. Install dependencies:
   npm install
3. (Optional) If you want to test locally:
   npm run dev
4. To build for production:
   npm run build
5. Upload the project folder (or push to GitHub and import) to Vercel. Vercel will install dependencies and deploy.

Formspree:
- Create a free account at https://formspree.io and get your form endpoint like https://formspree.io/f/xxxxxx
- Update components/ContactForm.js: replace FORM_ENDPOINT constant with your endpoint string.
- Redeploy on Vercel.

Contact details included in site:
- Company: S&P ENTERPRISES
- Owner: Satish Dhakne
- Phones: 9892255431, 9702055431
- Email: sandpenterprises793@gmail.com
- Address: Shop No 5, Krishna Colony, Opp SBI Bank, R T Road, Dahisar East, Mumbai 400068

